import React from 'react';

export default function Home() {
  return (
    
      <main className="text-9xl flex min-h-screen flex-col items-center justify-between p-24">
        รักเมียครับ <br />
        (เมียใคร )
      </main>
     
 
  );
}
